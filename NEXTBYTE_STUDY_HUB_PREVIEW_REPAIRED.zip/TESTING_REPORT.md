# NEXTBYTE — Study Hub Preview Repair Testing Report

Date: November 20, 2026

## Repair summary

- Replaced the legacy Study Hub `openMaterial()` direct-link/download behavior with a redirect to the shared NEXTBYTE in-app preview pipeline. The final `window.openMaterial` alias points to `nbPreviewStudyMaterial`.
- Removed the older override that opened a cached Blob in another browser tab or created a signed download URL.
- Replaced the Android-sensitive PDF iframe approach with PDF.js canvas rendering. The viewer includes previous/next page, page count, zoom, and fit-to-width controls.
- Added an accessible loading indicator, image/audio/video errors, corrupt/unsupported preview messages, and prevention of stacked preview sheets.
- Added Open from Device using the browser file picker. Selected files are read locally and are not uploaded to Supabase.
- Preserved private `user-study-files` Storage and the existing IndexedDB database/object store. Offline copies now retain filename, MIME, file ID, Storage path, bucket, and signed-in user ID. Cloud preview/download checks the current user and ignores cached file records belonging to another account.
- PDF.js main and worker runtime files are fetched from a pinned CDN release when absent, cached in IndexedDB, and its auxiliary same-version CDN assets are cached by the service worker while the PDF is prepared. The compiled PDF.js files are **not** physically bundled in `vendor/pdfjs`; see `vendor/pdfjs/README.md`.
- Added DOCX preview with Mammoth and XLS/XLSX preview with SheetJS. PowerPoint is kept intact and receives an explicit not-supported message.
- Updated the service-worker cache namespace to `nexbyte-pwa-v17-file-preview-device-picker`. Supabase API and private Storage requests are not cached by the service worker.

## Automated checks completed in this environment

| Check | Result | Evidence / scope |
|---|---|---|
| HTML parse | PASS | `index.html` parsed with Python's HTMLParser. |
| Inline JavaScript syntax | PASS | All 8 inline script blocks extracted and passed `node --check`. |
| Service-worker syntax | PASS | `sw.js` passed `node --check`. |
| Preview handler routing | PASS (static) | One final `window.openMaterial = window.nbPreviewStudyMaterial` alias exists; legacy direct-tab handlers were removed. |
| Preview renderer path | PASS (static) | PDF.js `page.render()` canvas code exists; the preview code contains no PDF iframe. |
| Download function duplication | PASS (static) | Exactly one `nbxDownloadPath()` definition remains. |
| Device picker | PASS (static) | File input and Open from Device event path are present. |
| IndexedDB ownership metadata | PASS (static) | Offline file records store account ID and cloud preview/download checks it. |
| Service worker version | PASS (static) | Cache namespace is v17. |
| Project ZIP integrity | PASS | The final archive was created and passed `unzip -t` / ZIP member CRC validation. |

## Not verified here — requires deployment/device access

- Live Supabase authentication, signed URL creation, private Storage policies, and retrieval of actual user files.
- Actual PDF.js CDN module and worker initialization in the target Android browser. The container has no validated live network session to these CDNs.
- Real PDF page rendering against normal, multi-page, malformed, or generic-MIME PDFs.
- Actual CMap/font/WASM cache population and offline replay under the deployed service worker. The code requires the service worker to control the page before marking PDF offline preparation complete, but this must still be tested on device.
- Mammoth and SheetJS CDN loading and document fidelity on actual DOCX/XLSX files.
- Image/audio/video codecs and the Android file picker on the user's device.
- Live Vercel deployment, cross-device sync, browser storage quota, and regression testing of all app sections.

## Required post-deployment test sequence

1. Upload the extracted project files to the existing GitHub repository root and deploy through the connected Vercel project. Keep `supabase-config.js` unchanged.
2. Open NEXTBYTE online and sign in. Reload once after the new service worker installs so the page is controlled by it.
3. Open a cloud PDF in Study Hub. Confirm its actual pages render inside the preview sheet and that the Android native PDF "Open" prompt no longer appears. Test page navigation, zoom, and fit width.
4. In the preview, select **Download & save offline**. Wait for the offline status to confirm the PDF and viewer assets have been prepared. Close and reopen the file.
5. Disable network access and reopen the same file on the same device. Confirm the cached PDF and viewer render. Repeat with a second PDF containing multiple pages and non-standard fonts if available.
6. Select **Open from Device** and choose a supported file from the phone's Downloads folder. Confirm it previews locally and is not uploaded.
7. Test PNG/JPG, TXT, CSV, MP4/WebM, MP3/WAV, DOCX, XLSX. Verify unsupported PPT/PPTX produces a clear message and preserves download access.
8. Sign in as another account on the same device and verify that the first account's cached file is not exposed through the second account's workspace.
9. Test syllabus attachments, task attachments, material folders, file deletion, upload refresh, Home, Study Rooms, Notes, Tasks, Profile, and bottom navigation.

## Important limitations

- Offline copies are local to the device and account. They do not transfer automatically between devices.
- The first preview-engine setup requires internet access. Each device must prepare its own viewer libraries and offline file copy.
- DOCX conversion is a readable content view, not a pixel-perfect Word page layout. Spreadsheet and CSV previews are capped at 200 rows and 20 columns; text preview is capped at 250,000 characters.
- PPT/PPTX are not rendered in-app by this build. MOV/M4V playback depends on browser codec support.
- Do not describe this repair as fully validated until the post-deployment tests above are completed.
