NEXTBYTE — FILE PREVIEW REPAIR PACKAGE SETUP

BEFORE YOU START
1. Make a backup of the current GitHub repository.
2. Keep the existing Supabase project URL and anon/publishable key in supabase-config.js. Never place a service_role/secret key in frontend files.
3. Do not delete Supabase tables, buckets, user rows, or policies. This preview repair does not require a SQL migration or a new Storage bucket.

DEPLOY TO GITHUB AND VERCEL
1. Download and extract the complete corrected ZIP on your device.
2. Open the existing GitHub repository and upload the extracted project contents, not the ZIP file by itself. Put index.html, sw.js, supabase-config.js, manifest.webmanifest, icons, and the other project files at the same repository-root paths used by the existing deployment.
3. Keep the existing supabase-config.js unchanged. Do not replace the Supabase project or credentials.
4. Commit the changes to the branch connected to Vercel.
5. In Vercel, confirm the deployment reaches Ready.
6. Open NEXTBYTE while online, sign in, and reload once after the new service worker has installed so it controls the page.

FILE PREVIEW BEHAVIOR
- Study Hub Materials, syllabus files, and task attachments use the same in-app preview pipeline. Legacy openMaterial() calls are redirected to this viewer.
- PDFs are rendered with PDF.js into an HTML canvas, with page navigation, zoom, and fit-to-width controls. They are not delegated to the Android native PDF viewer iframe.
- Images, TXT/Markdown, CSV, common audio/video, DOCX, XLSX, and XLS have in-app previews. Video codec support depends on the browser. PowerPoint (PPT/PPTX) is preserved but shows a compatibility message instead of a fake preview.
- **Open from Device** uses the browser's file picker to preview a file selected from the phone. It does not upload the selected file to Supabase.
- **Download & save offline** keeps a separate copy in the existing IndexedDB store and starts a normal device download. Offline copies remain on that device only.

PDF.JS AND OFFICE PREVIEW ENGINES
- PDF.js is loaded from a pinned CDN release on first online use, then cached in IndexedDB. The service worker caches the same-version auxiliary PDF.js assets requested while pages are prepared. This package does not include the compiled PDF.js files in vendor/pdfjs; vendor/pdfjs/README.md explains the optional self-hosted override paths.
- DOCX and XLS/XLSX previews load their browser libraries from pinned CDN locations and cache the runtime scripts in IndexedDB after first online use.
- To prepare a PDF for offline viewing: ensure the service worker controls the page (reload online after deployment), open the PDF, then choose Download & save offline. Wait for NEXTBYTE to report that the PDF and viewer are saved offline.
- If the page is not controlled by the service worker yet, the app deliberately does not mark a PDF as offline-ready. Refresh online and repeat the offline-save step.

SUPABASE SECURITY AND DATA
- Existing private user-study-files bucket and Storage paths are preserved. Signed URLs are used for authenticated access; the project does not make the bucket public.
- Local cached file records include account ownership metadata, and cloud previews/downloads check the current signed-in account before using the file.
- No database schema, bucket, or RLS policy migration is included or required for this preview repair. Keep existing RLS policies intact.

KNOWN LIMITATIONS
- Live Supabase account/Storage tests, Vercel deployment, and Android-device tests cannot be completed from this local repair environment. See TESTING_REPORT.md for the exact static checks and the remaining deployment tests.
- DOCX rendering preserves readable document structure but may not match Word's exact page layout. Spreadsheet previews are limited to 200 rows and 20 columns per worksheet. CSV previews are limited similarly. Text previews are limited to 250,000 characters.
- PowerPoint presentations are not rendered in-app in this build. The original file remains available for download.
- MOV/M4V and other media playback depends on codecs available in the browser.
- Offline cloud files and cached viewer libraries are device-specific; save the file separately on every device that needs offline access.
