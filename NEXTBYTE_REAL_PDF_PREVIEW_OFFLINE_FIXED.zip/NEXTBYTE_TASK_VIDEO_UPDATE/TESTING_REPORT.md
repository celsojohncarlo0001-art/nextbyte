# NEXTBYTE — PDF Preview Engine and Offline Access Testing Report

Date: November 20, 2026

## Implemented in this build

1. Study Hub Materials, Syllabus attachments, and Task Supporting Files share one preview path. The file bytes are retrieved through the authenticated private `user-study-files` bucket and are not opened with a download-disposition URL.
2. PDFs are rendered as actual canvas pages using PDF.js rather than relying on the Android WebView's native PDF handler. The viewer includes previous/next page, page count, zoom in/out, and fit-width controls.
3. PDF.js 6.5.438 is pinned. The loader prefers local files under `vendor/pdfjs/` when present. In this supplied ZIP those compiled distribution files are not included; when local files are absent, the main module and worker are fetched from the pinned jsDelivr package and cached in the existing IndexedDB database.
4. PDF.js requests its CMaps, standard fonts, and WASM helpers from the same pinned package. The service worker caches those exact PDF.js distribution requests as they are used. PDF download/offline-save also warms the document page-by-page while online so its required assets can be cached for offline rendering.
5. Preview checks the device's IndexedDB file cache first. A saved PDF or other supported file can be rendered from its local Blob without requesting the user's Supabase file again. A PDF is not labelled fully available offline until its exact cached record has a matching PDF.js version/readiness marker written after successful page-by-page warm-up.
6. Download & Save Offline saves a Blob using the existing stable `offline_material_<storage-path>` key and starts a download with the original filename. The separate Materials Offline action stores a local copy without needing to start a browser download. For PDFs, both actions mark the document as offline-viewer-ready only after the PDF.js runtime, worker, and every page's required rendering resources have completed the online warm-up.
7. Image, video, audio, text, and CSV previews remain supported. Unsupported document formats show a clear compatibility message and a separate download action.
8. Closing the preview releases Blob URLs, cancels PDF rendering, and destroys the PDF document, including when the sheet is dismissed through the overlay.

## Checks performed

- All 6 inline JavaScript blocks: syntax checked.
- `sw.js` and `supabase-config.js`: syntax checked.
- HTML parser sanity check: passed.
- Targeted source checks: PDF.js main/worker loader, canvas renderer, page controls, IndexedDB file cache, PDF auxiliary asset options, offline warm-up, separate Preview/Download controls, and service-worker cache version: passed.
- Browser-level PDF canvas renderer test using a mocked PDF.js API in Chromium: passed. Verified canvas creation, page 1/3 display, next-page navigation to 2/3, zoom interaction, and canvas dimensions. This tests the viewer UI/render integration but is not a real PDF.js distribution test.
- ZIP integrity check: run at packaging time.

## Not verified in this environment

- Live fetch of the PDF.js distribution from jsDelivr, because network access from the build environment was unavailable. The pinned URL is configured in the application, but actual end-user CDN delivery must be tested after deployment.
- Real user PDFs rendered by the actual PDF.js engine on the user's Android browser. The Chromium test used a mocked PDF.js API.
- Actual Supabase Storage permission checks, signed URL responses, and authenticated file uploads.
- Full IndexedDB persistence across Android app termination/restart on the user's device. The attempted local browser storage test could not run because local HTTP navigation was blocked by the execution environment.
- Actual Android download manager behavior, storage quota limits, Vercel deployment, and cross-device access. IndexedDB persistence across Android app termination/restart was attempted but the local browser test environment blocked navigation, so it remains unverified.

## Important first-use requirement

The supplied ZIP does **not** physically bundle the compiled PDF.js library. It first checks for matching self-hosted files in `vendor/pdfjs/`; if they are absent, it fetches the pinned main module and worker from jsDelivr and stores them in IndexedDB. The service worker caches auxiliary PDF.js resources as they are requested. Therefore the first PDF viewer setup needs an internet connection. After the matching engine and the document's required auxiliary resources have been cached on that device, offline PDF preview is available there. For a strict no-CDN deployment, add the matching `pdfjs-dist@6.5.438` build and asset directories using `vendor/pdfjs/README.md`.

## User verification steps

1. Deploy the files inside this project folder as the root of the existing Vercel project. Preserve `supabase-config.js`.
2. Open NEXTBYTE while online and allow the updated service worker to activate.
3. Open a PDF in Study Hub Materials and confirm that actual pages render inside NEXTBYTE. Use Previous, Next, Zoom, and Fit width.
4. Choose Download & Save Offline (or the Materials Offline action). Wait for the confirmation that the local file and viewer are saved.
5. Close and reopen the preview while still online once to allow any additional document-specific PDF.js assets to be cached.
6. Confirm the preview status says the PDF and viewer are saved offline. Disconnect from the internet, reopen the same file, and confirm actual pages render from the local IndexedDB copy. If NEXTBYTE reports that viewer setup is incomplete, reconnect and repeat Download & Save Offline while online.
7. Repeat using a Task Supporting File. Offline copies are device-specific; save files separately on every device that needs offline access.
